<div class="card my-4">
          <h5 class="card-header">Related Articles</h5>
          <div class="card-body">
		<nav class="nav flex-column">
		  <a class="nav-link active" href="#">PHP Training</a>
		  <a class="nav-link" href="#">CodeIgniter 4 Training</a>
		  <a class="nav-link" href="#">Drupal 9 Development</a>
		  <a class="nav-link" href="#">Laravel Training</a>
		  <a class="nav-link" href="#">Wordpress Development Training</a>
		  <a class="nav-link" href="#">More...</a>
		</nav>
		</div>
	  </div>
<footer class="bg-primary px-2 py-2">
            <div>
                <p class="text-center">&copy; 2020 All Copy rights reserved</p>
            </div>
        </footer>
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="<?= base_url(); ?>/public/assets/js/jquery-3.2.1.slim.min.js"></script>
        <script src="<?= base_url(); ?>/publicassets/js/popper.min.js"></script>
        <script src="<?= base_url(); ?>/publicassets/js/bootstrap.min.js" ></script>
    </body>
</html>
<div class="container">
                    <h2 class='text-center py-5 text-primary'>Our Features</h2>
                    <div class="row">
                        <div class="col-md-3 text-center">
                            <p class="display-4 text-primary"><i class="fa fa-user"></i></p>
                            <h5>The Page title goes here</h5>
                            <p>This program is free software; you can redistribute it and/or modify it</p>
                        </div>
                        <div class="col-md-3 text-center">
                            <p class="display-4 text-primary"><i class="fa fa-cogs"></i></p>
                            <h5>The Page title goes here</h5>
                            <p>This program is free software; you can redistribute it and/or modify it</p>
                        </div>
                        <div class="col-md-3 text-center">
                            <p class="display-4 text-primary"><i class="fa fa-envelope"></i></p>
                            <h5>The Page title goes here</h5>
                            <p>This program is free software; you can redistribute it and/or modify it</p>
                        </div>
                        <div class="col-md-3 text-center">
                            <p class="display-4 text-primary"><i class="fa fa-twitter"></i></p>
                            <h5>The Page title goes here</h5>
                            <p>This program is free software; you can redistribute it and/or modify it</p>
                        </div>

                        <div class="col-md-3 text-center">
                            <p class="display-4 text-primary"><i class="fa fa-facebook"></i></p>
                            <h5>The Page title goes here</h5>
                            <p>This program is free software; you can redistribute it and/or modify it</p>
                        </div>
                        <div class="col-md-3 text-center">
                            <p class="display-4 text-primary"><i class="fa fa-linkedin"></i></p>
                            <h5>The Page title goes here</h5>
                            <p>This program is free software; you can redistribute it and/or modify it</p>
                        </div>
                        <div class="col-md-3 text-center">
                            <p class="display-4 text-primary"><i class="fa fa-youtube"></i></p>
                            <h5>The Page title goes here</h5>
                            <p>This program is free software; you can redistribute it and/or modify it</p>
                        </div>
                        <div class="col-md-3 text-center">
                            <p class="display-4 text-primary"><i class="fa fa-google"></i></p>
                            <h5>The Page title goes here</h5>
                            <p>This program is free software; you can redistribute it and/or modify it</p>
                        </div>
                    </div>
                </div>
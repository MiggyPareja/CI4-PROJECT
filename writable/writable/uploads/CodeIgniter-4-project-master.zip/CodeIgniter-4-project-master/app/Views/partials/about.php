<div class="jumbotron">
                <div class="container">
                    <h1 class="display-4"><i>About Us</i></h1>

                    <p class="lead">GoPHP is a platform for learning Web Technologies like: PHP, MySQL, WordPress, Drupal, Joomla, CodeIgnitor, Web Services, AngularJS, Javascript, Jquery and more…</p>
                    <hr class="my-4">
                    <p>We are providing Online classes, Class room training and Corporate training as well. Our main GOAL is to provide Quality of education with real time professionals. Each and every training includes a Real Time Project development. Here, our experts provides full guidelines to the students on: How to learn a technology ?,&nbsp;Coding Standards, Job Assistance and more</p>
                    <p class="lead">
                        <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
                    </p>
                </div>
            </div>

        <div class="banner">
            <img class="img-fluid" src="<?= base_url(); ?>/public/assets/images/b3.jpg">
        </div>

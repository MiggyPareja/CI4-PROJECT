<?php
namespace Config;

class CustomRules {
    public function email_exists(string $str):bool{
        return true;
    }
}

<?php



namespace App\Controllers;
use \CodeIgniter\Controller;

class One extends Controller {
    
    public function __construct() {
        
    }
    public function index(){
       // $data = ['mobile'=>'1234567890']; 
       // return $this->parser->setData($data)->render('filterview');
    }
}
